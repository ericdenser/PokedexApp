//
//  PokedexAppApp.swift
//  PokedexApp
//
//  Created by Eric on 29/07/25.
//

import SwiftUI

@main
struct PokedexAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

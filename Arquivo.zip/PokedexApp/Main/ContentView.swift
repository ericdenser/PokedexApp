//
//  ContentView.swift
//  PokedexApp
//
//  Created by Eric on 29/07/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ExibirPokedex()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


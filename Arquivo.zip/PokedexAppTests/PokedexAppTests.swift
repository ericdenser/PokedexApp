//
//  PokedexAppTests.swift
//  PokedexAppTests
//
//  Created by Eric on 29/07/25.
//

import Testing
@testable import PokedexApp

struct PokedexAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
